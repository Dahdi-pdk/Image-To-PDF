package com.tes;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;

import java.io.ByteArrayOutputStream;

/**
 * Class untuk melakukan kompresi bitmap dengan berbagai metode
 * 
 * PERBAIKAN KRITIS:
 * - Untuk level NONE, tidak melakukan resize (kembalikan ke behavior konsep asli)
 * - Untuk level NONE, hanya proses grayscale jika diminta
 * - Tidak ada JPEG compression untuk level NONE
 */
public class BitmapCompressor {
    
    private CompressionSettings settings;

    public BitmapCompressor(CompressionSettings settings) {
        this.settings = settings;
    }

    /**
     * Kompresi bitmap dengan target ukuran tertentu
     * 
     * PERBAIKAN: Untuk level NONE, return original tanpa resize!
     * Ini sesuai dengan konsep asli yang tidak melakukan premature resize.
     */
    public Bitmap compressBitmap(Bitmap original, int targetWidth, int targetHeight) {
        if (original == null) {
            return null;
        }

        // ✅ FIX KRITIS: Untuk NONE, jangan resize sama sekali!
        // Biarkan original size, scaling akan dilakukan di canvas saat rendering
        if (settings.getLevel() == CompressionSettings.CompressionLevel.NONE) {
            Bitmap result = original;

            // ❌ HAPUS RESIZE - ini yang menyebabkan kompresi!
            // Di konsep asli, tidak ada resize untuk NONE
            // if (targetWidth > 0 && targetHeight > 0) {
            //     result = resizeBitmap(result, targetWidth, targetHeight);
            // }

            // Grayscale tetap dihormati karena itu pilihan user yang terpisah
            if (settings.isConvertToGrayscale()) {
                result = convertToGrayscale(result);
            }

            // ✅ Return original size (atau grayscale version dengan original size)
            return result;
        }

        // Untuk level lain (LOW, MEDIUM, HIGH, MAXIMUM), proses normal
        Bitmap result = original;

        // Step 1: Downsampling
        if (settings.getDownsamplingFactor() > 1) {
            result = downsampleBitmap(result, settings.getDownsamplingFactor());
        }

        // Step 2: Resize to target dimensions
        if (targetWidth > 0 && targetHeight > 0) {
            result = resizeBitmap(result, targetWidth, targetHeight);
        }

        // Step 3: Convert to grayscale
        if (settings.isConvertToGrayscale()) {
            result = convertToGrayscale(result);
        }

        // Step 4: JPEG compression — hanya untuk level selain NONE
        result = applyJpegCompression(result, settings.getJpegQuality());

        return result;
    }

    /**
     * Downsampling bitmap dengan faktor tertentu
     */
    private Bitmap downsampleBitmap(Bitmap source, int factor) {
        if (factor <= 1) {
            return source;
        }

        int newWidth = source.getWidth() / factor;
        int newHeight = source.getHeight() / factor;

        if (newWidth < 1) newWidth = 1;
        if (newHeight < 1) newHeight = 1;

        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true);
    }

    /**
     * Resize bitmap ke ukuran target
     */
    private Bitmap resizeBitmap(Bitmap source, int targetWidth, int targetHeight) {
        if (source.getWidth() == targetWidth && source.getHeight() == targetHeight) {
            return source;
        }

        return Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true);
    }

    /**
     * Konversi bitmap ke grayscale
     */
    private Bitmap convertToGrayscale(Bitmap source) {
        Bitmap grayscaleBitmap = Bitmap.createBitmap(
                source.getWidth(),
                source.getHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(grayscaleBitmap);
        Paint paint = new Paint();

        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0);

        ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrix);
        paint.setColorFilter(filter);

        canvas.drawBitmap(source, 0, 0, paint);

        return grayscaleBitmap;
    }

    /**
     * Apply JPEG compression dengan kualitas tertentu.
     * JANGAN panggil method ini saat level NONE.
     */
    private Bitmap applyJpegCompression(Bitmap source, int quality) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        source.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);

        byte[] byteArray = outputStream.toByteArray();

        return android.graphics.BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
    }

    /**
     * Estimate ukuran file hasil kompresi
     */
    public long estimateCompressedSize(int originalWidth, int originalHeight) {
        int pixelCount = originalWidth * originalHeight;

        // ✅ FIX: Untuk NONE, tidak ada downsampling (original size)
        int factor = settings.getDownsamplingFactor();
        if (settings.getLevel() != CompressionSettings.CompressionLevel.NONE && factor > 1) {
            pixelCount = pixelCount / (factor * factor);
        }

        float qualityFactor = settings.getJpegQuality() / 100.0f;

        // Jika NONE, gunakan lossless estimate (PNG-like) dengan original size
        long estimatedSize;
        if (settings.getLevel() == CompressionSettings.CompressionLevel.NONE) {
            estimatedSize = (long) (originalWidth * originalHeight * 3 * 0.8f); // PNG ~80% dari raw
        } else {
            estimatedSize = (long) (pixelCount * 3 * qualityFactor);
            estimatedSize = (long) (estimatedSize * 0.5f);
        }

        if (settings.isConvertToGrayscale()) {
            estimatedSize = (long) (estimatedSize * 0.33f);
        }

        return estimatedSize;
    }

    /**
     * Format ukuran file menjadi string yang mudah dibaca
     */
    public static String formatFileSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        } else if (bytes < 1024 * 1024) {
            return String.format("%.1f KB", bytes / 1024.0f);
        } else {
            return String.format("%.2f MB", bytes / (1024.0f * 1024.0f));
        }
    }
}
